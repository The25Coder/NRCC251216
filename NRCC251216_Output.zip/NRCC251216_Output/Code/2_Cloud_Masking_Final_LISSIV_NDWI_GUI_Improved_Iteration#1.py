import numpy as np
import rasterio
from tkinter import filedialog, Tk, messagebox, Button, Label
import matplotlib.pyplot as plt
import os

# What’s Improved in This Final Version:

# Deletes old masks before saving new ones

# Adjusted NDWI and shadow logic for better water/shadow detection

# Clean RGB overlay with clear visualization

# Error handling & graceful exit

# Submission-ready and tested layout

# Date : 26/6/2025.


class MaskingApp:
    def __init__(self, master):
        self.master = master
        master.title("Cloud & Shadow Masking - LISS-IV Final Version")

        self.label = Label(master, text="Select 3-band GeoTIFF (Green, Red, NIR)")
        self.label.pack(pady=10)

        self.select_button = Button(master, text="Select Image", command=self.select_file)
        self.select_button.pack(pady=5)

        self.run_button = Button(master, text="Run Masking", command=self.run_masking, state='disabled')
        self.run_button.pack(pady=5)

        self.view_button = Button(master, text="View Result", command=self.view_results, state='disabled')
        self.view_button.pack(pady=5)

        self.input_file = None
        self.combined_mask = None
        self.rgb = None

    def select_file(self):
        self.input_file = filedialog.askopenfilename(
            title="Select 3-band GeoTIFF",
            filetypes=[("TIFF files", "*.tif"), ("All files", "*.*")]
        )
        if self.input_file:
            self.label.config(text=f"Selected:\n{os.path.basename(self.input_file)}")
            self.run_button.config(state='normal')
        else:
            messagebox.showwarning("No File", "Please select a valid input file.")

    def run_masking(self):
        if not self.input_file:
            messagebox.showerror("Error", "No input file selected.")
            return

        try:
            with rasterio.open(self.input_file) as src:
                green = src.read(1).astype(float)
                red = src.read(2).astype(float)
                nir = src.read(3).astype(float)
                profile = src.profile

            # Normalize
            def normalize(img):
                p2, p98 = np.percentile(img, (2, 98))
                return np.clip((img - p2) / (p98 - p2 + 1e-6), 0, 1)

            green_n = normalize(green)
            red_n = normalize(red)
            nir_n = normalize(nir)

            # Compute NDWI
            ndwi = (green_n - nir_n) / (green_n + nir_n + 1e-6)
            brightness = (green_n + red_n + nir_n) / 3

            # Water
            #water_mask = ndwi > 0.1
            water_mask = (ndwi > 0.001)
            #& (nir_n < 0.3)

            # Cloud
            cloud_mask = (
                ((green_n > 0.65) & (red_n > 0.65)) |
                (brightness > 0.75)
            ) & (~water_mask)

            


            shadow_mask = (
                  (nir_n < 0.18) &  # Allow slightly brighter shadows
                  (brightness < 0.35) &  # Allow slightly brighter pixels overall
                  (np.abs(green_n - red_n) < 0.03) &
                  (np.abs(red_n - nir_n) < 0.03) &
                  (~cloud_mask) &
                  (~water_mask)
             )


            print("Shadow pixels Count(***********):", np.sum(shadow_mask))
            print("Cloud pixels: ", np.sum(cloud_mask))
            print("Shadow pixels:", np.sum(shadow_mask))
            print("Water pixels: ", np.sum(water_mask))

            # Combined mask
            combined_mask = np.zeros_like(green, dtype=np.uint8)
            combined_mask[cloud_mask] = 1
            combined_mask[shadow_mask] = 2
            combined_mask[water_mask] = 3

            #self.combined_mask = combined

            # Save masks
            mask_profile = profile.copy()
            mask_profile.update(dtype=rasterio.uint8, count=1, nodata=0)

            base_filename = os.path.splitext(self.input_file)[0]
            
            
            self.cloud_mask_path = base_filename + "_cloud_mask.tif"
            self.shadow_mask_path = base_filename + "_shadow_mask.tif"
            self.water_mask_path = base_filename + "_water_mask.tif"
            self.combined_mask_path = base_filename + "_combined_mask.tif"

            # Delete old masks if they exist
            for path in [self.cloud_mask_path, self.shadow_mask_path, self.water_mask_path, self.combined_mask_path]:
                if os.path.exists(path):
                    os.remove(path)

            with rasterio.open(self.cloud_mask_path, 'w', **mask_profile) as dst:
                dst.write((cloud_mask.astype(np.uint8) * 255), 1)

            with rasterio.open(self.shadow_mask_path, 'w', **mask_profile) as dst:
                dst.write((shadow_mask.astype(np.uint8) * 255), 1)

            with rasterio.open(self.water_mask_path, 'w', **mask_profile) as dst:
                dst.write((water_mask.astype(np.uint8) * 255), 1)

            with rasterio.open(self.combined_mask_path, 'w', **mask_profile) as dst:
                dst.write(combined_mask, 1)

            self.combined_mask = combined_mask    

            # RGB Overlay
            def create_rgb(nir, red, green):
                return np.dstack([normalize(nir), normalize(red), normalize(green)])

            self.rgb = create_rgb(nir, red, green)
            alpha = 0.5
            self.rgb[cloud_mask] = (1 - alpha) * self.rgb[cloud_mask] + alpha * np.array([1, 0, 0])
            self.rgb[shadow_mask] = (1 - alpha) * self.rgb[shadow_mask] + alpha * np.array([0, 0, 1])
            self.rgb[water_mask] = (1 - alpha) * self.rgb[water_mask] + alpha * np.array([0, 1, 1])

            messagebox.showinfo("Success", "All masks generated and saved successfully.")
            self.view_button.config(state='normal')

        except Exception as e:
            messagebox.showerror("Error", f"Processing failed:\n{e}")

    def view_results(self):
        if self.rgb is not None:
            plt.figure(figsize=(10, 10))
            plt.imshow(self.rgb)
            plt.title("Cloud (Red), Shadow (Blue), Water (Cyan)")
            plt.axis('off')
            plt.tight_layout()
            plt.show()
        else:
            messagebox.showwarning("No Output", "Please run the masking first.")

if __name__ == "__main__":
    root = Tk()
    app = MaskingApp(root)
    root.mainloop()
