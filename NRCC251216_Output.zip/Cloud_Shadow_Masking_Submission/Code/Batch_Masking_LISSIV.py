import os
import numpy as np
import rasterio
import pandas as pd

#Date: 3/7/2025

def compute_ndwi(green, nir):
    return (green - nir) / (green + nir + 1e-6)

def compute_brightness(green, red, nir):
    return (green + red + nir) / 3

def process_image(image_path, output_folder):
    name = os.path.splitext(os.path.basename(image_path))[0]

    with rasterio.open(image_path) as src:
        img = src.read()
        profile = src.profile

    # Normalize by 700 as per LISS-IV radiometry
    green = img[0] / 700.0
    red   = img[1] / 700.0
    nir   = img[2] / 700.0

    ndwi = compute_ndwi(green, nir)
    brightness = compute_brightness(green, red, nir)

    # Classification logic
    water_mask = (ndwi > 0.3) & (nir < 0.25) & (brightness > 0.2)
    cloud_mask = (brightness > 0.20) & (ndwi < 0.0)
    shadow_mask = (nir < 0.2) & (brightness < 0.3) & (~cloud_mask) & (~water_mask)


    ##Added Section###
    # Save individual masks
    profile.update(dtype=rasterio.uint8, count=1)

    def save_mask(mask, suffix):
        out_path = os.path.join(output_folder, f"{name}_{suffix}.tif")
        with rasterio.open(out_path, "w", **profile) as dst:
            dst.write(mask.astype(rasterio.uint8), 1)

    save_mask(water_mask,"Water_mask")
    save_mask(cloud_mask,"Cloud_mask")
    save_mask(shadow_mask,"Shadow_mask")

    ##

    # Build final mask
    final_mask = np.zeros_like(nir, dtype=np.uint8)
    final_mask[water_mask] = 1
    final_mask[(cloud_mask) & (final_mask == 0)] = 2
    final_mask[(shadow_mask) & (final_mask == 0)] = 3

    # Save classified GeoTIFF
    profile.update(dtype=rasterio.uint8, count=1)
    out_path = os.path.join(output_folder, f"{name}_classified_mask.tif")
    with rasterio.open(out_path, "w", **profile) as dst:
        dst.write(final_mask.astype(rasterio.uint8), 1)

    return {
        "Image": name,
        "Water Pixels": int(np.sum(water_mask)),
        "Cloud Pixels": int(np.sum(cloud_mask)),
        "Shadow Pixels": int(np.sum(shadow_mask))
    }

def run_batch(input_folder, output_folder):
    os.makedirs(output_folder, exist_ok=True)

    tif_files = [f for f in os.listdir(input_folder)
                 if f.lower().endswith(".tif") and "composite" in f.lower()]

    all_stats = []
    for tif in tif_files:
        print(f"Processing: {tif}")
        path = os.path.join(input_folder, tif)
        stats = process_image(path, output_folder)
        all_stats.append(stats)

    df = pd.DataFrame(all_stats)
    df.to_csv(os.path.join(output_folder, "mask_pixel_counts.csv"), index=False)
    print("\n✅ Done. All results saved in:", output_folder)

# === Your Folder Structure ===
#input_folder = r"D:\NRSC_Coding_Challenge_July2025\R2F29OCT2024070211010100062SSANSTUC00GTDB_subset1\R2F29OCT2024070211010100062SSANSTUC00GTDB_subset1"
#output_folder = r"D:\NRSC_Coding_Challenge_July2025\R2F29OCT2024070211010100062SSANSTUC00GTDB_subset1\Masks"

#input_folder = r"D:\NRSC_Coding_Challenge_July2025\R2F30OCT2024070225010600057SSANSTUC00GTDB_subset1\R2F30OCT2024070225010600057SSANSTUC00GTDB_subset1\\"
#output_folder = r"D:\NRSC_Coding_Challenge_July2025\R2F30OCT2024070225010600057SSANSTUC00GTDB_subset1\Masks\\"

#input_folder = r"D:\NRSC_Coding_Challenge_July2025\RAF01NOV2020020248009600062SSANSTUC00GTDB_subset1\RAF01NOV2020020248009600062SSANSTUC00GTDB_subset1\\"
#output_folder = r"D:\NRSC_Coding_Challenge_July2025\RAF01NOV2020020248009600062SSANSTUC00GTDB_subset1\RAF01NOV2020020248009600062SSANSTUC00GTDB_subset1\\"

#input_folder = r"D:\NRSC_Coding_Challenge_July2025\RAF16APR2025043371009400047SSANSTUC00GTDD_subset1\RAF16APR2025043371009400047SSANSTUC00GTDD_subset1\\"
#output_folder = r"D:\NRSC_Coding_Challenge_July2025\RAF16APR2025043371009400047SSANSTUC00GTDD_subset1\Masks\\"

input_folder = r"D:\NRSC_Coding_Challenge_July2025\RAF20APR2025043422009000055SSANSTUC00GTDB_subset1\RAF20APR2025043422009000055SSANSTUC00GTDB_subset1\\"
output_folder = r"D:\NRSC_Coding_Challenge_July2025\RAF20APR2025043422009000055SSANSTUC00GTDB_subset1\Masks\\"


run_batch(input_folder, output_folder)

print("*****SUCCESS****")
