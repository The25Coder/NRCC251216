import tkinter as tk
from tkinter import filedialog, messagebox
import rasterio
import numpy as np
import os

## Here's a GUI-based Python program using Tkinter that:
##
##✅ Lets you select 3 individual band files (e.g., Band1, Band2, Band3)
##✅ Lets you choose the output file path
##✅ Creates the RGB composite with a single click

## Date: 2/7/2025

def composite_bands(band_r_path, band_g_path, band_b_path, output_path):
    try:
        with rasterio.open(band_r_path) as red:
            red_data = red.read(1)
            meta = red.meta.copy()

        with rasterio.open(band_g_path) as green:
            green_data = green.read(1)

        with rasterio.open(band_b_path) as blue:
            blue_data = blue.read(1)

        # Stack as R, G, B
        rgb = np.stack([red_data, green_data, blue_data])
        meta.update({"count": 3, "dtype": rgb.dtype, "driver": "GTiff"})

        with rasterio.open(output_path, "w", **meta) as dst:
            dst.write(rgb)

        messagebox.showinfo("Success", f"Composite saved:\n{output_path}")
    except Exception as e:
        messagebox.showerror("Error", f"Failed to create composite:\n{e}")

def browse_band(entry):
    filename = filedialog.askopenfilename(title="Select Band File", filetypes=[("TIFF files", "*.tif")])
    if filename:
        entry.delete(0, tk.END)
        entry.insert(0, filename)

def browse_output(entry):
    filename = filedialog.asksaveasfilename(title="Save Composite As", defaultextension=".tif", filetypes=[("TIFF files", "*.tif")])
    if filename:
        entry.delete(0, tk.END)
        entry.insert(0, filename)

def generate_composite():
    band_r = entry_r.get()
    band_g = entry_g.get()
    band_b = entry_b.get()
    output = entry_out.get()

    if not all([band_r, band_g, band_b, output]):
        messagebox.showwarning("Missing Input", "Please select all bands and output file path.")
        return

    composite_bands(band_r, band_g, band_b, output)

# GUI Setup
root = tk.Tk()
root.title("LISS-IV Band Composite Creator")

tk.Label(root, text="Band 1 (Red or NIR):").grid(row=0, column=0, sticky="e")
entry_r = tk.Entry(root, width=60)
entry_r.grid(row=0, column=1)
tk.Button(root, text="Browse", command=lambda: browse_band(entry_r)).grid(row=0, column=2)

tk.Label(root, text="Band 2 (Green or Red):").grid(row=1, column=0, sticky="e")
entry_g = tk.Entry(root, width=60)
entry_g.grid(row=1, column=1)
tk.Button(root, text="Browse", command=lambda: browse_band(entry_g)).grid(row=1, column=2)

tk.Label(root, text="Band 3 (Blue or Green):").grid(row=2, column=0, sticky="e")
entry_b = tk.Entry(root, width=60)
entry_b.grid(row=2, column=1)
tk.Button(root, text="Browse", command=lambda: browse_band(entry_b)).grid(row=2, column=2)

tk.Label(root, text="Output Composite File:").grid(row=3, column=0, sticky="e")
entry_out = tk.Entry(root, width=60)
entry_out.grid(row=3, column=1)
tk.Button(root, text="Browse", command=lambda: browse_output(entry_out)).grid(row=3, column=2)

tk.Button(root, text="Create Composite", command=generate_composite, bg="green", fg="white").grid(row=4, column=1, pady=10)

root.mainloop()
