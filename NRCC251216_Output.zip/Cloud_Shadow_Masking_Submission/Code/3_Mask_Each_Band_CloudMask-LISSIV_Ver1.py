import numpy as np
import rasterio
import os
from tkinter import filedialog, Tk, messagebox, Button, Label

# === INPUT FILES ===

print("Program Started-Mask Each Band")

print("1. Select 3-Band Composite Image for application of mask")
input_path = filedialog.askopenfilename(title="Select 3-band GeoTIFF",filetypes=[("TIFF files", "*.tif"), ("All files", "*.*")])

print("2. Select Cloud Mask File  for application of mask")
cloud_mask_path = filedialog.askopenfilename(title="Select Cloud Mask GeoTIFF",filetypes=[("TIFF files", "*.tif"), ("All files", "*.*")])

print("3. Provide Masked Output Image Name")
output_path = filedialog.asksaveasfilename(defaultextension=".tif",filetypes=[("TIFF files", "*.tif"), ("All files", "*.*")],title="Save Output Masked Image As")

if not output_path:
    messagebox.showwarning("No Output", "No output file selected!")
    exit()

print(output_path)


# === Step 1: Load image ===
with rasterio.open(image_path) as src:
    profile = src.profile
    bands = src.read().astype('float32')  # (3, H, W)
    print("Loaded image shape:", bands.shape)

# === Step 2: Load mask ===
with rasterio.open(cloud_mask_path) as msk:
    mask = msk.read(1).astype(bool)
    print("Loaded mask shape:", mask.shape)

# === Check shape consistency ===
if mask.shape != bands.shape[1:]:
    raise ValueError("Mask shape does not match image shape!")

# === Step 3: Apply mask ===
masked = bands.copy()
masked[:, mask] = 0  # Try also: masked[:, mask] = np.nan

# === Debug: Check some values ===
print("Sample pixel (before mask):", bands[:, mask][0:3])
print("Sample pixel (after mask):", masked[:, mask][0:3])

# === Step 4: Save ===
profile.update(dtype='float32')
with rasterio.open(output_path, 'w', **profile) as dst:
    dst.write(masked)

print("Saved cloud-masked image:", output_path)
