import numpy as np
import rasterio
import os
from tkinter import filedialog, Tk, messagebox, Button, Label

# The script:

##1.Loads your 3-band LISS-IV composite (Green, Red, NIR)

##2.Converts each band from DN to TOA reflectance using the formula

## 3.Creates a new TOA Reflectance composite and saves it

##Date : 20/6/2025

def dn_to_toa_auto_scaled(dn, max_dn, sun_elev_deg):
    return np.clip((dn.astype(np.float32) / max_dn) / np.sin(np.radians(sun_elev_deg)), 0, 1)

# === File paths ===

print("Program Started")
print("Select 3-Band Composite Image for generating TOA Image")
input_file = filedialog.askopenfilename(title="Select 3-band GeoTIFF",filetypes=[("TIFF files", "*.tif"), ("All files", "*.*")])
output_file = input_file.replace(".tif", "_TOA_Composite_new.tif")
sun_elevation = 70.180912

# === Max DNs from earlier inspection ===
max_dns = [596, 609, 671]  # Green, Red, NIR

# === Read, convert and write ===
with rasterio.open(input_file) as src:
    profile = src.profile.copy()
    profile.update(dtype=rasterio.float32)

    toa_bands = []
    for i in range(3):
        band_dn = src.read(i + 1)
        toa = dn_to_toa_auto_scaled(band_dn, max_dns[i], sun_elevation)
        toa_bands.append(toa)

    toa_stack = np.stack(toa_bands)
    profile.update(count=3)

    with rasterio.open(output_file, 'w', **profile) as dst:
        dst.write(toa_stack.astype(np.float32))

print(f"✅ TOA composite created and saved:\n{output_file}")

