import numpy as np
import rasterio
import matplotlib.pyplot as plt

# ==== Load image ====
#image_path = r"D:\YourFolder\Your_LISSIV_Composite.tif"  # Change this
image_path = r"D:\NRSC_Coding_Challenge_July2025\R2F06JUN2025073330009700059SSANSTUC00GTDA_subset1\R2F06JUN2025073330009700059SSANSTUC00GTDA_subset1\R2F06JUN2025Composite.tif"

with rasterio.open(image_path) as src:
    green = src.read(1).astype(np.float32)
    red = src.read(2).astype(np.float32)
    nir = src.read(3).astype(np.float32)


print("Raw NIR min/max:", nir.min(), nir.max())
print("Raw RED min/max:", red.min(), red.max())
print("Raw GREEN min/max:", green.min(), green.max())

# ==== Normalize ====
green_n = green / 700.0
red_n = red / 700.0
nir_n = nir / 700.0

# ==== Optional: dummy masks ====
cloud_mask = np.zeros_like(nir_n, dtype=bool)
water_mask = np.zeros_like(nir_n, dtype=bool)

# ==== Shadow Diagnostic Starts ====
brightness = (green_n + red_n + nir_n) / 3.0

print("\n--- Diagnostic Report ---")
print("NIR_n min/max:", np.min(nir_n), np.max(nir_n))
print("Red_n min/max:", np.min(red_n), np.max(red_n))
print("Green_n min/max:", np.min(green_n), np.max(green_n))
print("Brightness min/max:", np.min(brightness), np.max(brightness))

plt.figure(figsize=(10, 3))
plt.subplot(1, 3, 1); plt.hist(nir_n.flatten(), bins=100); plt.title("NIR_n")
plt.subplot(1, 3, 2); plt.hist(brightness.flatten(), bins=100); plt.title("Brightness")
plt.subplot(1, 3, 3); plt.hist((green_n - red_n).flatten(), bins=100); plt.title("Green - Red")
plt.tight_layout(); plt.show()

print("Cloud pixels:", np.sum(cloud_mask))
print("Water pixels:", np.sum(water_mask))
print("Total pixels:", nir_n.size)
print("Pixels available after masking:", np.sum(~cloud_mask & ~water_mask))

mask1 = (nir_n < 0.15)
mask2 = (brightness < 0.25)
mask_combined = mask1 & mask2 & (~cloud_mask) & (~water_mask)

print("Mask1 (nir_n < 0.15):", np.sum(mask1))
print("Mask2 (brightness < 0.25):", np.sum(mask2))
print("Combined shadow_mask:", np.sum(mask_combined))

shadow_mask = mask_combined

from datetime import datetime
print("Shadow mask updated at:", datetime.now().strftime("%H:%M:%S"))
print("--- End Diagnostic ---\n")
