import numpy as np
import rasterio
from tkinter import filedialog, Tk, messagebox, Button, Label
import matplotlib.pyplot as plt
import os

# What’s Improved in This Final Version:

# Deletes old masks before saving new ones

# Adjusted NDWI and shadow logic for better water/shadow detection

# Clean RGB overlay with clear visualization

# Error handling & graceful exit

# Submission-ready and tested layout

# Date : 26/6/2025 & 3rd July,2025.


class MaskingApp:
    def __init__(self, master):
        self.master = master
        master.title("Cloud & Shadow Masking - LISS-IV Final Version")

        self.label = Label(master, text="Select 3-band GeoTIFF (Green, Red, NIR)")
        self.label.pack(pady=10)

        self.select_button = Button(master, text="Select Image", command=self.select_file)
        self.select_button.pack(pady=5)

        self.run_button = Button(master, text="Run Masking", command=self.run_masking, state='disabled')
        self.run_button.pack(pady=5)

        self.view_button = Button(master, text="View Result", command=self.view_results, state='disabled')
        self.view_button.pack(pady=5)

        self.input_file = None
        self.combined_mask = None
        self.rgb = None

    def select_file(self):
        self.input_file = filedialog.askopenfilename(
            title="Select 3-band GeoTIFF",
            filetypes=[("TIFF files", "*.tif"), ("All files", "*.*")]
        )
        if self.input_file:
            self.label.config(text=f"Selected:\n{os.path.basename(self.input_file)}")
            self.run_button.config(state='normal')
        else:
            messagebox.showwarning("No File", "Please select a valid input file.")

    def run_masking(self):
        if not self.input_file:
            messagebox.showerror("Error", "No input file selected.")
            return

        # Ask for output folder
        output_folder = filedialog.askdirectory(title="Select Output Folder to Save Masks")
        if not output_folder:
            messagebox.showwarning("No Folder", "Output folder not selected.")
            return

        try:
            with rasterio.open(self.input_file) as src:
                green = src.read(1).astype(float)
                red = src.read(2).astype(float)
                nir = src.read(3).astype(float)
                profile = src.profile

##            # Normalize
##            def normalize(img):
##                p2, p98 = np.percentile(img, (2, 98))
##                return np.clip((img - p2) / (p98 - p2 + 1e-6), 0, 1)
##
##            green_n = normalize(green)
##            red_n = normalize(red)
##            nir_n = normalize(nir)

            # Use this for cloud/shadow/water detection logic
            green_n = green / 700.0
            red_n = red / 700.0
            nir_n = nir / 700.0

            # Compute NDWI
            ndwi = (green_n - nir_n) / (green_n + nir_n + 1e-6)
            brightness = (green_n + red_n + nir_n) / 3

            print("NIR_n min/max:", nir_n.min(), nir_n.max())
            print("Brightness min/max:", brightness.min(), brightness.max())

            

            # Water
            #water_mask = ndwi > 0.1
            #water_mask = (ndwi > 0.001)

            ##Diagonostic Water Mask Block

            # Water analysis block
            water_mask_test1 = ndwi > 0.2
            water_mask_test2 = nir_n < 0.3
            water_mask_test3 = brightness < 0.4
            water_mask = water_mask_test1 & water_mask_test2 & water_mask_test3

            print("\n--- Water Diagnostic ---")
            print("NDWI > 0.3:", np.sum(water_mask_test1))
            print("NIR_n < 0.25:", np.sum(water_mask_test2))
            print("Final water pixels (combined):", np.sum(water_mask))
            print("--- End Water Diagnostic ---\n")
            

            ##End of Water
           
            #water_mask = (ndwi > 0.3) & (brightness < 0.25)
            #print("Water pixels:", np.sum(water_mask))

            




           ##DIAGONOSTIC CLOUD MASKING BLOCK

            # --- Cloud Diagnostic Start ---
            print("\n--- Cloud Diagnostic ---")

            # Step 1: NDWI
            ndwi = (green_n - nir_n) / (green_n + nir_n + 1e-6)
            print("NDWI min/max:", np.min(ndwi), np.max(ndwi))

            # Step 2: Individual conditions
            cond1 = (brightness > 0.35)
            cond2 = (ndwi < 0.0)
            cond3 = (nir < 0.4)

            print("Condition 1 (brightness > 0.25):", np.sum(cond1))
            print("Condition 2 (ndwi < 0.0):", np.sum(cond2))
            print("Condition 3 (nir < 0.4):", np.sum(cond3))

            # Step 3: Combined condition
            cloud_mask = cond1 & cond2      # & cond3
            print("Cloud pixels:", np.sum(cloud_mask))

            print("--- End Cloud Diagnostic ---\n")
            
            
           ##BLOCK END 

           #Shadow:Ver1
##            shadow_mask = (
##                  (nir_n < 0.18) &  # Allow slightly brighter shadows
##                  (brightness < 0.35) &  # Allow slightly brighter pixels overall
##                  (np.abs(green_n - red_n) < 0.03) &
##                  (np.abs(red_n - nir_n) < 0.03) &
##                  (~cloud_mask) &
##                  (~water_mask)
##             )


            # Shadow — improved logic-Version2 

##            shadow_mask = (
##                (nir_n < 0.1) &
##                (brightness < 0.15) &
##                (np.abs(green_n - red_n) < 0.05) &
##                (np.abs(red_n - nir_n) < 0.05) &
##                (~water_mask)
##            )

            #Shadow Mask-Improved on 3.7.2025
            
            

##            shadow_mask = (
##                (nir_n < 0.15) &
##                (brightness < 0.25) &
##                (~cloud_mask) & (~water_mask)
##            )

            #3SHADOW DIAGONOSTIC BLOCK
            print("\n--- Shadow Diagnostic ---")
            print("NIR_n min/max:", np.min(nir_n), np.max(nir_n))
            print("Brightness min/max:", np.min(brightness), np.max(brightness))

            cond_nir = nir_n < 0.22 #0.18
            cond_bright = brightness < 0.35
            combined_shadow = cond_nir & cond_bright & (~cloud_mask) & (~water_mask)
            shadow_mask = cond_nir & cond_bright & (~cloud_mask) & (~water_mask)

            print("NIR < 0.18:", np.sum(cond_nir))
            print("Brightness < 0.3:", np.sum(cond_bright))
            print("Cloud pixels:", np.sum(cloud_mask))
            print("Water pixels:", np.sum(water_mask))
            print("Final shadow pixels:", np.sum(combined_shadow))
            print("--- End Shadow Diagnostic ---\n")

            

            ##


            ##Extra
            #(green_n < 0.3) & (red_n < 0.3) &
            #(np.abs(green_n - red_n) < 0.015) &
            #(np.abs(red_n - nir_n) < 0.015) &
            ##

            overlap = shadow_mask & water_mask
            print("\n--- Mask Overlap Check ---")
            print("Shadow–Water Overlap (should be 0):", np.sum(overlap))
            print("--- End ---\n")


            print("Shadow pixels Count(***********):", np.sum(shadow_mask))
            print("Cloud pixels: ", np.sum(cloud_mask))
            print("Shadow pixels:", np.sum(shadow_mask))
            print("Water pixels: ", np.sum(water_mask))

            # Combined mask
            combined_mask = np.zeros_like(green, dtype=np.uint8)
            combined_mask[cloud_mask] = 1
            combined_mask[shadow_mask] = 2
            combined_mask[water_mask] = 3

            #self.combined_mask = combined

            # Save masks
            mask_profile = profile.copy()
            mask_profile.update(dtype=rasterio.uint8, count=1, nodata=0)

            #base_filename = os.path.splitext(self.input_file)[0]
            #print(base_filename)
            #exit()

            # Create output paths inside selected folder
            input_basename = os.path.splitext(os.path.basename(self.input_file))[0]
            self.cloud_mask_path = os.path.join(output_folder, input_basename + "_cloud_mask.tif")
            self.shadow_mask_path = os.path.join(output_folder, input_basename + "_shadow_mask.tif")
            self.water_mask_path = os.path.join(output_folder, input_basename + "_water_mask.tif")
            self.combined_mask_path = os.path.join(output_folder, input_basename + "_combined_mask.tif")

            
            #self.cloud_mask_path = base_filename + "_cloud_mask.tif"
            #self.shadow_mask_path = base_filename + "_shadow_mask.tif"
            #self.water_mask_path = base_filename + "_water_mask.tif"
            #self.combined_mask_path = base_filename + "_combined_mask.tif"

            # Delete old masks if they exist
            for path in [self.cloud_mask_path, self.shadow_mask_path, self.water_mask_path, self.combined_mask_path]:
                if os.path.exists(path):
                    os.remove(path)

            with rasterio.open(self.cloud_mask_path, 'w', **mask_profile) as dst:
                dst.write((cloud_mask.astype(np.uint8) * 255), 1)

            with rasterio.open(self.shadow_mask_path, 'w', **mask_profile) as dst:
                dst.write((shadow_mask.astype(np.uint8) * 255), 1)

            with rasterio.open(self.water_mask_path, 'w', **mask_profile) as dst:
                dst.write((water_mask.astype(np.uint8) * 255), 1)

            with rasterio.open(self.combined_mask_path, 'w', **mask_profile) as dst:
                dst.write(combined_mask, 1)

            self.combined_mask = combined_mask    

            # RGB Overlay
            def create_rgb(nir, red, green):
                return np.dstack([normalize(nir), normalize(red), normalize(green)])

            self.rgb = create_rgb(nir, red, green)
            alpha = 0.5
            self.rgb[cloud_mask] = (1 - alpha) * self.rgb[cloud_mask] + alpha * np.array([1, 0, 0])
            self.rgb[shadow_mask] = (1 - alpha) * self.rgb[shadow_mask] + alpha * np.array([0, 0, 1])
            self.rgb[water_mask] = (1 - alpha) * self.rgb[water_mask] + alpha * np.array([0, 1, 1])

            messagebox.showinfo("Success", "All masks generated and saved successfully.")
            self.view_button.config(state='normal')

        except Exception as e:
            messagebox.showerror("Error", f"Processing failed:\n{e}")

    def view_results(self):
        if self.rgb is not None:
            plt.figure(figsize=(10, 10))
            plt.imshow(self.rgb)
            plt.title("Cloud (Red), Shadow (Blue), Water (Cyan)")
            plt.axis('off')
            plt.tight_layout()
            plt.show()
        else:
            messagebox.showwarning("No Output", "Please run the masking first.")

if __name__ == "__main__":
    root = Tk()
    app = MaskingApp(root)
    root.mainloop()



##Extraa Matter
##        # Cloud - Ver1.
##            cloud_mask = (
##                ((green_n > 0.65) & (red_n > 0.65)) |
##                (brightness > 0.75)
##            ) & (~water_mask)

##            # Cloud-Ver2
##            cloud_mask = (
##                ((green_n > 0.45) & (red_n > 0.45)) |
##                (brightness > 0.55)
##            ) & (~water_mask)

            
##           # Cloud - Ver3.
##            cloud_mask = (
##                ((green_n > 0.85) & (red_n > 0.85)) |
##                (brightness > 0.95)
##            ) & (~water_mask)

             # Cloud - Ver4.
##            cloud_mask = (
##                ((green_n > 0.95) & (red_n > 0.95)) |
##                (brightness > 0.95)
##            ) & (~water_mask)
            
## water_mask = (ndwi > 0.15) & (nir_n < 0.3) & (brightness > 0.2)
